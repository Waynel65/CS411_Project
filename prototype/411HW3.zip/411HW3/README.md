Make sure to install all imports:
    pip install flask
    pip install requests
    pip install pillow

To run, just type "py 411Project" in terminal
The website should be displayed in address http://127.0.0.1:5000/

You need to change the value of OAuthToken in the python code to a valid token
link to OAuth Token Generator: https://developer.spotify.com/console/get-search-item/ 